print("Hello World!")

print("Hello World") 
print("Hello Again!")


print("Hello\tWorld\t!")
print("Hi\tWorld\t!")
print("Hey\tAll\t!")
print("Yo\tEarth\t!")

print("The \\t character is my favorite special character!")
print("The \\" +"t character is my favorite special character!")
