print("Please input your name:\t")
name = input()
print("Hello, there, %s!"%(name))